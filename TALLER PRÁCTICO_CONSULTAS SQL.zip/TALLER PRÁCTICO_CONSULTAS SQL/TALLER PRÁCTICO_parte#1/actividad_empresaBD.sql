use empresaBD;

-- 1. Todos los registros de la tabla departamento
select * from departamento;

-- 2. Todos los empleados registrados en la empresa
select * from empleados;

-- 3. Solo nombre, apellido y salario de los empleados
select nombre, apellido, salario from empleados;

-- 4. Empleados con edad superior a 30 años
select * from empleados where edad > 30;

-- 5. Empleados con salario superior a $4.000.000
select * from empleados where salario > 4000000;

-- 6. Empleados cuyo nombre sea 'Laura'
select * from empleados where nombre = 'Laura';

-- 7. Departamentos ubicados en el edificio principal
select * from departamento where ubicacion like '%Edificio principal%';