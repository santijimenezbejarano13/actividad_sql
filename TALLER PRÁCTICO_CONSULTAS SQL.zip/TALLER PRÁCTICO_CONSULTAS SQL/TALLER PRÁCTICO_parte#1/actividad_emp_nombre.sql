use empresaBD;

insert into empleados (empID, nombre, apellido, edad, salario, deptID) values
(101, 'Laura',     'Gomez',    29, 3200000.00, 1),
(102, 'Carlos',    'Ramirez',  35, 4500000.00, 2),
(103, 'Andres',    'Martinez', 27, 3800000.00, 2),
(104, 'Diana',     'Torres',   41, 5200000.00, 3),
(105, 'Sofia',     'Herrera',  31, 4100000.00, 4),
(106, 'Miguel',    'Castro',   38, 3600000.00, 5);

commit;