use empresaBD;

update empleados set deptID = 2 where empID = 103;

insert into empleados (empID, nombre, apellido, edad, salario, deptID) values
(107, 'Valentina', 'Rojas',   26, 3000000.00, 1),
(108, 'Jorge',     'Moreno',  45, 6100000.00, 2),
(109, 'Camila',    'Diaz',    33, 4700000.00, 3),
(110, 'Felipe',    'Ortiz',   24, 2800000.00, 4),
(111, 'Natalia',   'Vargas',  37, 3900000.00, 5),
(112, 'Daniel',    'Silva',   30, 3400000.00, 6),
(113, 'Paula',     'Mendoza', 28, 3300000.00, 1),
(114, 'Ricardo',   'Acosta',  50, 7200000.00, 3),
(115, 'Mariana',   'Pineda',  32, 4400000.00, 4),
(116, 'Sebastian', 'Navarro', 22, 2500000.00, 6),
(117, 'Gabriela',  'Leon',    39, 5300000.00, 2),
(118, 'Esteban',   'Cortes',  34, 4200000.00, 5),
(119, 'Isabella',  'Reyes',   25, 3100000.00, 6),
(120, 'Oscar',     'Fuentes', 43, 4900000.00, 5);

commit;