create database if not exists empresaBD;
use empresaBD;
create table departamento(
    deptID int not null,
    nombreDEPTO varchar(100) not null,
    ubicacion varchar(100) not null,
    constraint PK_departamento primary key(deptID),
    constraint UQ_departamento unique(nombreDEPTO)
);