use empresaBD;

create table empleados(
    empID int not null,
    nombre varchar(60) not null,
    apellido varchar(60) not null,
    edad tinyint unsigned not null,
    salario decimal(12,2) not null,
    deptID int not null,
    constraint PK_Empleado primary key(empID),
    constraint FK_Empleado_departamento
        foreign key(deptID)
        references departamento(depID)
        on update cascade
        on delete restrict,
    constraint CK_Empleados_edad check (edad between 18 and 120),
    constraint CK_Empleados_Salario check (salario >= 0)
);