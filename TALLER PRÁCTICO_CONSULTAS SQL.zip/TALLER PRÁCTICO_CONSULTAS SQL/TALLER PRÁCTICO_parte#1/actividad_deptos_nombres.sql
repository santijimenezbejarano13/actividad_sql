use empresaBD;

insert into departamento (depID, nombreDEPTO, ubicacion) values
(1, 'Recursos Humanos', 'Piso 2 - Edificio principal'),
(2, 'Tecnología', 'Piso 3 - Edificio principal'),
(3, 'Finanzas', 'Piso 2 - Edificio principal'),
(4, 'Mercadeo', 'Piso 1 - Edificio principal'),
(5, 'Ventas', 'Sede comercial'),
(6, 'Operaciones', 'Centro Logístico');